Instruções

1 - Para rodar o pipeline, basta executar "run_grid.py"
2 - Para gerar gráficos e tabelas, basta executar "analyze_results.py"